
IF ( OBJECT_ID('XMTS_AsignaPago', 'P') IS NOT NULL ) begin
    DROP PROCEDURE XMTS_AsignaPago;  
end;
GO  
create PROCEDURE [dbo].[XMTS_AsignaPago] (
    @empresa char(2),
    @idmaeedo int,
    @sucursal char(3),
    @caja char(2),
    @emisorDocPago char(13),
    @cuentaPago varchar(16),    /* $NumCuenta */
    @cuentaNro varchar(8),      /* $DigTj' */
    @monto decimal(18,3),
    @rutEmpresa char(10),       /* ej: '79567780-1' */
	@Error int output, 
	@ErrMsg NVARCHAR(4000) output )
with encryption
AS
BEGIN
    --
    SET NOCOUNT ON
    -- 
    declare @id_dpce int,
            @tido char(3),
            @funcionario char(3), 
			@nudp char(10),
			@endp char(13),
			@errDesc nvarchar(2048);
	declare @mi_tidp char(2),
			@mi_koendp char(13),
			@mi_suendp char(3);
    --
    set @id_dpce = 0;
    --  
    SELECT @funcionario = KOFUDO, @tido = TIDO FROM MAEEDO with (nolock) WHERE IDMAEEDO = @idmaeedo ;
    -- se incorpora tabla que decodifica transbank
    -- select * from kmts_medios_pago
	select @mi_tidp = codigoerp,@mi_koendp = koendp, @mi_suendp = suendp
	from kmts_medios_pago
	where codigotb = @emisorDocPago;
	if ( @mi_tidp is null ) begin
		select @mi_tidp = codigoerp,@mi_koendp = koendp, @mi_suendp = suendp
		from kmts_medios_pago
		where codigotb = '00';
	end 
	-- 
	SELECT @endp = ENDO 
	FROM MAEEDO with (nolock)  
	WHERE IDMAEEDO = @idmaeedo;
	--
	Select @nudp = @caja + REPLACE(Str(CAST(RIGHT(MAX(NUDP),8) As Int) + 1,8),' ','0') 
	From MAEDPCE with (nolock) 
	Where SUREDP = @sucursal
	  and TIDP = @mi_tidp+'V'
	  and CJREDP = @caja;
	--
    insert into MAEDPCE (EMPRESA,TIDP,
                        NUDP,
                        ENDP,
                        EMDP,SUEMDP,CUDP,NUCUDP,FEEMDP,FEVEDP,
                        MODP,TIMODP,TAMODP,VADP,VAABDP,VAASDP,VAVUDP,ESASDP,ESPGDP,
                        SUREDP,CJREDP,KOFUDP,KOTNDP,SUTNDP,
                        NUTRANSMI,NUCOCO,KOTU,
                        REFANTI,DOCUENANTI,
                        IMDP,NULICO,PERIODO,TUVOPROTES,
                        FECHAPROTE,RESUMEN,KOENDOSO,NOENDOSO,NUVISA,KOVISADOR,
                        ARCHIRSD,IDRSD,
                        HORAGRAB,LAHORA,
                        CUOTAS,REFERENCIA,VADONDP,IDMAEDPTB ) 
                values ( @empresa,@mi_tidp+'V',
                        @nudp,
                        coalesce( @endp,''),
                        @mi_koendp,@mi_suendp,@cuentaPago,@cuentaNro,cast(getdate() as date), cast(getdate() as date),
                        '$','N',1,@monto,0,@monto,0,'A','P',
                        @sucursal,@caja,@funcionario,@rutEmpresa,@sucursal,
                        'totem','','1',
                        '','',
                        '','','',0,
                        NULL,'','','','','',
                        NULL,NULL,
                        (DATEPART(hour, GETDATE()) * 3600) + (DATEPART(minute, GETDATE()) * 60) + DATEPART(second, GETDATE()), cast(getdate() as date),
                        1,0,0,0 )
    --
    --select @id_dpce = @@IDENTITY ; 
    select @id_dpce = IDENT_CURRENT('MAEDPCE');
    -- 
    set @Error = @@error; 
    IF ( @Error <> 0 ) BEGIN
        set @errDesc = ERROR_MESSAGE();
        THROW @Error, @errDesc, 1; 
    END
    --
    insert into MAEDPCD ( IDMAEDPCE,VAASDP,FEASDP,TIDOPA,ARCHIRST,IDRST,TCASIG,REFERENCIA,
                          KOFUASDP,
                          SUASDP,CJASDP,HORAGRAB,LAHORA) 
                 VALUES ( @id_dpce,@monto,cast(getdate() as date),@tido,'MAEEDO',@idmaeedo,1,111,
                          @funcionario,@sucursal,@caja,
                          (DATEPART(hour, GETDATE()) * 3600) + (DATEPART(minute, GETDATE()) * 60) + DATEPART(second, GETDATE()), cast(getdate() as date) );
    --
    set @Error = @@error; 
    IF ( @Error <> 0 ) BEGIN
        set @errDesc = ERROR_MESSAGE();
        THROW @Error, @errDesc, 1; 
        -- RAISERROR ( @Error, @errDesc, 1 ) ;  
    END
    --
    -- actualizacion de MAEEDO y vencimientos
    UPDATE MAEVEN SET VAABVE = VAVE, ESPGVE = 'C' WHERE IDMAEEDO = @idmaeedo;
    UPDATE MAEEDO Set ESPGDO = 'C', VAABDO = @monto, TIDOELEC = 1 Where IDMAEEDO = @idmaeedo;
    --
END;
