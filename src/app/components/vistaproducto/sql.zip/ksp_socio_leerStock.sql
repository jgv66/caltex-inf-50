--
-- exec ksp_socio_leerStock '01','001'
--
IF OBJECT_ID('ksp_socio_leerStock', 'P') IS NOT NULL  
    DROP PROCEDURE ksp_socio_leerStock;  
GO  
CREATE PROCEDURE ksp_socio_leerStock (
    @empresa char(2) = '', 
    @bodega	 char(3) = '' ) With Encryption
AS
BEGIN
	--
    SET NOCOUNT ON;
	declare @noexisten int = 0,
			@condiferencia int = 0;	
    --
    declare @bode		char(3),
			@codigo		char(13),
			@fisico1	decimal(18,5),
			@fisico2	decimal(18,5),
			@algo		char(2),
			@sucursal   char(3);
	--	
	insert into ktb_socio_procesos (proceso,fecha) values ('analisis de stock bodega: '+@bodega+' empresa: '+@empresa, getdate() );
	--
	select @sucursal = KOSU from TABBO with (nolock) where EMPRESA=@empresa and KOBO=@bodega;
    -- nuevos en productos
    with lista as ( select @empresa as empresa,bo.KOSU as sucursal,bo.KOBO as bodega,bo.KOPR as codigo,coalesce(st.STFI1,0) as fisico1,coalesce(st.STFI2,0) as fisico2
					from TABBOPR as bo with (nolock) 
					inner join MAEPR with (nolock) on MAEPR.KOPR=bo.KOPR 
												  and MAEPR.BLOQUEAPR not in ('X','T','V')
												  and MAEPR.ATPR <>'OCU'
					inner join MAEPREM with (nolock) on MAEPREM.KOPR=MAEPR.KOPR and MAEPREM.EMPRESA=@empresa 
					left join MAEST as st with (nolock) on st.EMPRESA=bo.EMPRESA and st.KOSU=bo.KOSU and st.KOBO=bo.KOBO and st.KOPR=bo.KOPR
					where bo.EMPRESA = @empresa 
					  and bo.KOSU = @sucursal 
					  and bo.KOBO = @bodega ),
	noexisten as (	select li.*
					from lista as li
					left join ktb_socio_stock as st with (nolock) on st.empresa=li.empresa and st.sucursal=li.sucursal and st.bodega=li.bodega and st.codigo=li.codigo
					where st.codigo is null )
	select @noexisten = count(*) from noexisten;
	insert into ktb_socio_procesos (proceso,fecha) values ('productos nuevos '+cast( @noexisten as varchar(20)), getdate() );
	-- con diferencias
    with lista as ( select @empresa as empresa,bo.KOSU as sucursal,bo.KOBO as bodega,bo.KOPR as codigo,coalesce(st.STFI1,0) as fisico1,coalesce(st.STFI2,0) as fisico2
					from TABBOPR as bo with (nolock) 
					inner join MAEPR with (nolock) on MAEPR.KOPR=bo.KOPR 
												  and MAEPR.BLOQUEAPR not in ('X','T','V')
												  and MAEPR.ATPR <>'OCU'
					inner join MAEPREM with (nolock) on MAEPREM.KOPR=MAEPR.KOPR and MAEPREM.EMPRESA=@empresa 
					left join MAEST as st with (nolock) on st.EMPRESA=bo.EMPRESA and st.KOSU=bo.KOSU and st.KOBO=bo.KOBO and st.KOPR=bo.KOPR
					where bo.EMPRESA = @empresa 
					  and bo.KOSU = @sucursal 
					  and bo.KOBO = @bodega ),
	algodiferente as (	select li.*
						from lista as li
						inner join ktb_socio_stock as st with (nolock) on st.empresa=li.empresa and st.sucursal=li.sucursal and st.bodega=li.bodega and st.codigo=li.codigo
						where round(st.fisico1,0) <> round(li.fisico1,0) 
						   or round(st.fisico2,0) <> round(li.fisico2,0) )
	select @condiferencia=count(*) from algodiferente;
	insert into ktb_socio_procesos (proceso,fecha) values ('productos con diferencia '+cast( @condiferencia as varchar(20)), getdate() );
    
	-- El cursor esta abierto?
	IF ( (SELECT CURSOR_STATUS('global', 'detalle_cursor')) = 1 ) BEGIN
		CLOSE detalle_cursor		
		DEALLOCATE detalle_cursor
	END	
	--
	DECLARE detalle_cursor CURSOR FORWARD_ONLY STATIC READ_ONLY
	FOR 
    with lista as ( select @empresa as empresa,bo.KOSU as sucursal,bo.KOBO as bodega,bo.KOPR as codigo,coalesce(st.STFI1,0) as fisico1,coalesce(st.STFI2,0) as fisico2
					from TABBOPR as bo with (nolock) 
					inner join MAEPR with (nolock) on MAEPR.KOPR=bo.KOPR 
												  and MAEPR.BLOQUEAPR not in ('X','T','V')
												  and MAEPR.ATPR <>'OCU'
					inner join MAEPREM with (nolock) on MAEPREM.KOPR=MAEPR.KOPR and MAEPREM.EMPRESA=@empresa 
					left join MAEST as st with (nolock) on st.EMPRESA=bo.EMPRESA and st.KOSU=bo.KOSU and st.KOBO=bo.KOBO and st.KOPR=bo.KOPR
					where bo.EMPRESA = @empresa 
					  and bo.KOSU = @sucursal 
					  and bo.KOBO = @bodega ),
	noexisten as (	select li.*
					from lista as li
					left join ktb_socio_stock as st with (nolock) on st.empresa=li.empresa and st.sucursal=li.sucursal and st.bodega=li.bodega and st.codigo=li.codigo
					where st.codigo is null ),
	algodiferente as (	select li.*
						from lista as li
						inner join ktb_socio_stock as st with (nolock) on st.empresa=li.empresa and st.sucursal=li.sucursal and st.bodega=li.bodega and st.codigo=li.codigo
						where round(st.fisico1,0) <> round(li.fisico1,0) 
						   or round(st.fisico2,0) <> round(li.fisico2,0) )
    select bodega,codigo,fisico1, fisico2,'NE' as algo
    from noexisten
    union
    select bodega,codigo,fisico1, fisico2,'AD' as algo
    from algodiferente;
	--
	OPEN detalle_cursor  
	--
	FETCH NEXT FROM detalle_cursor INTO @bodega,@codigo,@fisico1,@fisico2,@algo;

	WHILE ( @@FETCH_STATUS = 0 ) BEGIN     
		--
		if ( @algo = 'NE' ) begin
			insert into ktb_socio_stock (empresa,sucursal,bodega,codigo,fisico1,fisico2,ultima_act)
			    values (@empresa,@sucursal,@bodega,@codigo,@fisico1,@fisico2,cast(getdate() as date));
		end
		else begin
			update ktb_socio_stock set fisico1=@fisico1, fisico2=@fisico2,ultima_act=cast(getdate() as date) 
			where empresa=@empresa 
			  and sucursal=@sucursal
			  and bodega=@bodega
			  and codigo=@codigo;
		end;
		--	
		FETCH NEXT FROM detalle_cursor INTO @bodega,@codigo,@fisico1,@fisico2,@algo;
	END;
	--
	CLOSE detalle_cursor  
	DEALLOCATE detalle_cursor  
	--	
	insert into ktb_socio_procesos (proceso,fecha) values ('fin analisis stock', getdate() );
	--
END;
go


