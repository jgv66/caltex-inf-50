
IF ( OBJECT_ID('XMTS_Transaccion', 'P') IS NOT NULL ) begin
    DROP PROCEDURE XMTS_Transaccion;  
end;
go

create PROCEDURE [dbo].[XMTS_Transaccion] 
    @empresa char(2),
    @idmaeedo int,
    @Modalidad char(5),
    @emisorDocPago char(13),
    @cuentaPago varchar(16),    
    @cuentaNro varchar(8),      
    @monto decimal(18,3),
    @rutEmpresa char(10) 
with encryption
AS
BEGIN
    -- 
    SET NOCOUNT ON;
    --
    declare @sucursal char(3);
	declare @caja char(2);
	declare @idfb int;
	declare @folioDefinitivo char(10);
    declare @ErrMsg NVARCHAR(4000);
	declare @ReturnValue int;
	declare @Error varchar(255);
    --
    begin TRY
        --
        set @ReturnValue = 0;
        --
		select @sucursal=ESUCURSAL,@caja=ECAJA
		from CONFIEST
		where EMPRESA=@empresa
		  and MODALIDAD=@Modalidad;
        --
        BEGIN TRANSACTION;
        --
		set @ReturnValue = 0;
		--
        exec XMTS_AsignaFolio @idmaeedo, @Modalidad, @ReturnValue output, @Error output, @ErrMsg output, @folioDefinitivo output ;
		--
        if ( ( @ReturnValue <> 0 ) and ( @Error = 0 ) ) BEGIN
            --
            exec XMTS_AsignaPago @empresa, @idmaeedo, @sucursal, @caja, @emisorDocPago, @cuentaPago, @cuentaNro, @monto, @rutEmpresa, @Error output, @ErrMsg output; 
            --
            if ( @Error<>0 ) begin 
                set @Error = @@ERROR;
                set @ErrMsg = ERROR_MESSAGE();
				THROW @Error, @ErrMsg, 0 ; 
            end;
            --
            if ( @@TRANCOUNT > 0 ) begin
                COMMIT TRANSACTION;
            end;
            --
            select cast(1 as bit) resultado, cast(0 as bit) error, '' as mensaje, @idfb as id, @folioDefinitivo as folio;
            --
        END
        else BEGIN
            --
            if ( @@TRANCOUNT > 0 ) begin
                ROLLBACK TRANSACTION;
            end;
            select cast(0 as bit) resultado, cast(1 as bit) error, @ErrMsg as mensaje, 0 as id, '' as folio;                
            --
        end;
        --
    end TRY
    begin CATCH
        --
        set @Error = @@ERROR;
        set @ErrMsg = ERROR_MESSAGE();
		--
		if ( @@TRANCOUNT > 0 ) begin
			ROLLBACK TRANSACTION;
		end;
        -- avisamos el error 
        select cast(0 as bit) resultado, cast(1 as bit) error, @ErrMsg as mensaje, '' as id,'' as folio; ;
        --
    end catch;
    -- 
END;