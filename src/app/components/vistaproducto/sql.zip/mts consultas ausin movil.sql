IF OBJECT_ID('ksp_TipoGoogle_OR', 'P') IS NOT NULL  
    DROP PROCEDURE ksp_TipoGoogle_OR;  
GO  
create procedure ksp_TipoGoogle_OR ( 
        @campo   varchar(20),   
        @cdescri varchar(2500), 
        @salida varchar(2500) OUTPUT ) With Encryption
AS 
BEGIN
    declare @ctoken     varchar(2500);
    declare @cdev       varchar(2500);
    declare @ccadena    varchar(2500);
    declare @n          int;
 
    set @campo      = LTRIM(RTRIM( @campo ));
    set @cdescri    = LTRIM(RTRIM( @cdescri ));
 
    set @ccadena    = @cdescri;
    set @n          = 1;
    set @cdev       = '';
 
    exec ksp_StrToken @ccadena,@n,' ',@salida = @ctoken output;
 
    WHILE @ctoken <> '' 
    BEGIN
        --
        if @n = 1
            set @cdev = @cdev + ' ';
        else
            set @cdev = @cdev + ' OR ';
        --   
        set @cdev += CONCAT( @campo,' LIKE ',char(39),'%', RTRIM(@ctoken), '%', char(39), ' ');
        set @n = @n + 1;
        exec ksp_StrToken @ccadena,@n,' ',@salida = @ctoken output;
     END
     select @salida = @cdev;
     RETURN
END 
go


-- declare @salida varchar(400); exec ksp_TipoGoogle_CODEFAM 'ACE,ALA,',',',@salida output ; print @salida ;
IF OBJECT_ID('ksp_TipoGoogle_CODEFAM', 'P') IS NOT NULL  
    DROP PROCEDURE ksp_TipoGoogle_CODEFAM;  
GO  
create procedure ksp_TipoGoogle_CODEFAM ( 
        @cdescri varchar(2500),
		@token char(1), 
        @salida varchar(2500) OUTPUT ) With Encryption
AS 
BEGIN
    declare @ctoken     varchar(2500);
    declare @cdev       varchar(2500);
    declare @ccadena    varchar(2500);
    declare @n          int;
	declare @campo      char(7) = '',
			@campo1     char(7) = 'PR.FMPR',
			@campo2		char(7) = 'PR.PFPR',
			@campo3		char(7) = 'PR.HFPR';
 
    set @cdescri    = LTRIM(RTRIM( @cdescri ));
 
    set @ccadena    = @cdescri;
    set @n          = 1;
    set @cdev       = '';
 
    exec ksp_StrToken @ccadena,@n,@token, @ctoken output;
 
    WHILE ( @ctoken <> '' ) BEGIN
        --
		set @cdev += case when @n = 1 then ' ' else ' and ' end;
        --
		set @campo = case when @n=1 then @campo1 when @n=2 then @campo2 when @n=3 then @campo3 end;    
        set @cdev += CONCAT( @campo,' LIKE ',char(39),'%', RTRIM(@ctoken), '%', char(39), ' ');
        set @n = @n + 1;
		--
        exec ksp_StrToken @ccadena,@n,@token,@salida = @ctoken output;
		--
     END
     select @salida = @cdev;
     RETURN
END 
go
 
-- exec ksp_bodegasxusuario 'WEB'
IF OBJECT_ID('ksp_bodegasxusuario', 'P') IS NOT NULL  
    DROP PROCEDURE ksp_bodegasxusuario;  
GO  
CREATE PROCEDURE ksp_bodegasxusuario ( 
	@usuario char(3) ) 
With Encryption
AS
BEGIN
	--	 
    SET NOCOUNT ON
	--
	select bo.KOBO as bodega, bo.NOKOBO as descripcion 
	from MAEUS as us with (nolock)
	inner join TABFU as fu with (nolock) on fu.KOFU = us.KOUS and fu.INACTIVO = 0
	left join TABBO as bo with (nolock) on bo.KOBO = substring(us.KOOP,4,3)
	where us.KOUS = @usuario
	  and us.KOOP like 'BO-%'
	--
END
go

-- exec ksp_stockxsucursal '01','ARC000905' ;
IF OBJECT_ID('ksp_stockxsucursal', 'P') IS NOT NULL  
    DROP PROCEDURE ksp_stockxsucursal;  
GO  
CREATE PROCEDURE ksp_stockxsucursal ( 
	@empresa char(2),
	@codigo char(13) ) 
With Encryption
AS
BEGIN
	--	 
    SET NOCOUNT ON
	--
	select su.KOSU as sucursal, su.NOKOSU as descripcion
			,sum(st.STFI1) as stock 
	from       MAEPR	as pr with (nolock) 
	inner join MAEPREM	as em with (nolock) on em.EMPRESA = @empresa and em.KOPR = pr.KOPR 
	left  join MAEST	as st with (nolock) on st.EMPRESA = em.EMPRESA and st.KOPR = em.KOPR
	left  join TABSU	as su with (nolock) on su.KOSU = st.KOSU
	where pr.KOPR = @codigo
	  and em.EMPRESA = @empresa
	group by su.KOSU, su.NOKOSU
	order by NOKOSU
	--
END
go

-- exec ksp_buscarClientes 'Ulio','Ulio',160;
IF OBJECT_ID('ksp_buscarClientes', 'P') IS NOT NULL  
    DROP PROCEDURE ksp_buscarClientes;  
GO  
CREATE PROCEDURE ksp_buscarClientes (
    @codcliente varchar(13) = '', 
    @razonsoc   varchar(50) = '',
	@offset		int = 0 ) With Encryption
AS
BEGIN
 
    SET NOCOUNT ON;
 
    declare @kodigo     varchar(60);
    declare @descri     varchar(200);
    declare @query      NVARCHAR(2500);
    declare @xkoen      varchar(500);
    declare @xnokoen    varchar(500);
    declare @anterior   varchar(100) = '';
    declare @posterior  varchar(100) = '';
    declare @principal  varchar(100) = '';
 	declare @paginar	varchar(150) = '';	

    set @codcliente = RTRIM(@codcliente);
    set @razonsoc   = RTRIM(@razonsoc);
 
    set @query   = 'select rtrim(EN.KOEN) as codigo,rtrim(EN.SUEN) AS sucursal, rtrim(EN.NOKOEN) as razonsocial,rtrim(EN.DIEN) as direccion,';
    set @query  +=        'rtrim(EN.KOFUEN) as vendedor, PP.KOLT as listaprecios,PP.KOLT as listaprecio,';
    set @query  +=        'rtrim(FU.NOKOFU) as nombrevendedor, rtrim(PP.NOKOLT) as nombrelista,';
    set @query  +=        'rtrim(CI.NOKOCI) as ciudad, rtrim(CM.NOKOCM) as comuna, rtrim(EN.EMAILCOMER) as email,rtrim(EN.FOEN) as telefonos,';
    set @query  +=        '( case when EN.TIPOSUC='+char(39)+'S'+char(39)+' then '+char(39)+'suc'+char(39)+' else '+char(39)+char(39)+' end ) as tiposuc,';
	set @query  +=		  'cast(coalesce(( select top 1 1 from MAEEN as su with (nolock) where EN.KOEN = su.KOEN and su.TIPOSUC=''S'' ),0) as bit) tienesucursales '
    set @query  += 'FROM MAEEN AS EN WITH (NOLOCK) ';
    set @query  += 'left join TABFU as FU with (nolock) on FU.KOFU=EN.KOFUEN ';
    set @query  += 'left join TABPP as PP with (nolock) on '+char(39)+'TABPP'+char(39)+'+PP.KOLT=EN.LVEN ';
    set @query  += 'left join TABCI as CI with (nolock) on CI.KOPA=EN.PAEN AND CI.KOCI=EN.CIEN ';
    set @query  += 'left join TABCM as CM with (nolock) on CM.KOPA=EN.PAEN AND CM.KOCI=EN.CIEN AND CM.KOCM=EN.CMEN ';
 
    -- pasadas por ksp_cambiatodo
    exec ksp_cambiatodo @codcliente, @salida = @kodigo OUTPUT ;
    exec ksp_cambiatodo @razonsoc,   @salida = @descri OUTPUT ;
 
    set @kodigo = case when @kodigo<>'' then '%'+@kodigo+'%' else '' end;
    set @descri = case when @descri<>'' then '%'+@descri+'%' else '' end;
 
    set @principal = ' AND EN.TIPOSUC=''P'' AND EN.TIEN in (''C'',''A'') ' ;  /* solo principal */
 
 	set @paginar = ' OFFSET '+rtrim(cast(@offset as varchar(5)))+' ROWS FETCH NEXT 20 ROWS ONLY; ';

    if ( @descri<>'' and @kodigo<>'' ) begin
        --
        exec ksp_TipoGoogle 'EN.KOEN',  @kodigo, @salida = @xkoen   output;
        exec ksp_TipoGoogle 'EN.NOKOEN',@descri, @salida = @xnokoen output;
        --
        set @query = concat( @query, ' WHERE ( ', @xkoen, ' or ',  @xnokoen,' ) ', @principal, ' ORDER BY EN.KOEN ', @paginar ); 
        EXECUTE sp_executesql @query
    end
    if ( @descri<>'' and @kodigo='' ) begin
        --
        exec ksp_TipoGoogle 'EN.NOKOEN',@descri, @salida = @xnokoen output;
        -- 
        set @query = concat( @query, ' WHERE ', @xnokoen, @principal, ' ORDER BY EN.KOEN ', @paginar ); 
        EXECUTE sp_executesql @query
	end
    if ( @descri='' and @kodigo<>'' ) begin
		--
        exec ksp_TipoGoogle 'EN.KOEN',  @kodigo, @salida = @xkoen   output;
        --
        set @query = concat( @query, ' WHERE ', @xkoen, @principal, ' ORDER BY EN.KOEN ', @paginar ); 
        EXECUTE sp_executesql @query
    end
END
GO

-- exec ksp_buscarSucursales 'Ulio','Ulio',160;
IF OBJECT_ID('ksp_buscarSucursales', 'P') IS NOT NULL  
    DROP PROCEDURE ksp_buscarSucursales;  
GO  
CREATE PROCEDURE ksp_buscarSucursales (
    @codcliente varchar(13) = '', 
	@offset		int = 0 ) With Encryption
AS
BEGIN
 
    SET NOCOUNT ON;
 
    declare @query      NVARCHAR(2500);
 	declare @paginar	varchar(150) = '';	
    declare @kodigo     varchar(60);
	declare @xkoen		varchar(100);
    declare @descri     varchar(200);
    declare @principal  varchar(200);

    set @codcliente = RTRIM(@codcliente);
 
    set @query   = 'select rtrim(EN.KOEN) as codigo,rtrim(EN.SUEN) AS sucursal, rtrim(EN.NOKOEN) as razonsocial,rtrim(EN.DIEN) as direccion,';
    set @query  +=        'rtrim(CI.NOKOCI) as ciudad, rtrim(CM.NOKOCM) as comuna, rtrim(EN.EMAILCOMER) as email,rtrim(EN.FOEN) as telefonos,';
    set @query  +=        '( case when EN.TIPOSUC='+char(39)+'S'+char(39)+' then '+char(39)+'suc'+char(39)+' else '+char(39)+char(39)+' end ) as tiposuc,';
	set @query  +=		  'cast(1 as bit) sucursal '
    set @query  += 'FROM MAEEN AS EN WITH (NOLOCK) ';
    set @query  += 'left join TABFU as FU with (nolock) on FU.KOFU=EN.KOFUEN ';
    set @query  += 'left join TABPP as PP with (nolock) on '+char(39)+'TABPP'+char(39)+'+PP.KOLT=EN.LVEN ';
    set @query  += 'left join TABCI as CI with (nolock) on CI.KOPA=EN.PAEN AND CI.KOCI=EN.CIEN ';
    set @query  += 'left join TABCM as CM with (nolock) on CM.KOPA=EN.PAEN AND CM.KOCI=EN.CIEN AND CM.KOCM=EN.CMEN ';
 
    -- pasadas por ksp_cambiatodo
    exec ksp_cambiatodo @codcliente, @salida = @kodigo OUTPUT ;
 
    set @kodigo = case when @kodigo<>'' then '%'+@kodigo+'%' else '' end;
 
    set @principal = ' AND EN.TIPOSUC=''S'' ' ;
 
 	set @paginar = ' OFFSET '+rtrim(cast(@offset as varchar(5)))+' ROWS FETCH NEXT 20 ROWS ONLY; ';

    exec ksp_TipoGoogle 'EN.KOEN', @kodigo, @salida = @xkoen   output;
	--
	set @query = concat( @query, ' WHERE ', @xkoen, @principal, ' ORDER BY EN.KOEN ', @paginar ); 
	EXECUTE sp_executesql @query;
	--
END
GO

IF OBJECT_ID('decoClaveRND', 'P') IS NOT NULL  
    DROP PROCEDURE decoClaveRND;  
GO  
CREATE PROCEDURE decoClaveRND ( 
       @llave	char(5), 
	   @valout	char(25) output ) 
With Encryption
AS
BEGIN
 
	declare @i		as int = 1,
			@dato	as int = 0,
			@val    as varchar(255);

	while ( @i < 6 ) begin
		set @dato = case 
						when @i = 1 then 17225
						when @i = 2 then 1847
						when @i = 3 then 1217
						when @i = 4 then 237
						when @i = 5 then 201
					end;
		set @val = concat( rtrim(@val) , cast( ( ( ascii( substring(@llave,@i,1) ) + @dato ) * @i * @i * @i ) as char(5) ));
		set @i = @i + 1;
	end
	set @valout = rtrim(@val);
END 
go

-- exec ksp_login 'mts@mts.cl','TEST1';
IF OBJECT_ID('ksp_login', 'P') IS NOT NULL  
    DROP PROCEDURE ksp_login;  
GO  
CREATE PROCEDURE ksp_login ( 
    @codigoemail varchar(100), 
    @rut         varchar(50)) 
With Encryption
AS
BEGIN
    SET NOCOUNT ON
 
    declare @kodigo varchar(100);
    declare @xrut   varchar(2500);
	declare @dekey	char(25) = '';
 
    set @xrut   = RTRIM(@rut) ;
    set @kodigo = RTRIM(@codigoemail);

    exec decoClaveRND @xrut, @dekey output ;

    select  F.KOFU as usuario
			,F.NOKOFU as nombre
			,F.RTFU as rut
			,F.MODALIDAD as modalidad
			,F.EMAIL as email
			,BO.KOSU AS sucursal
			,SU.NOKOSU as nombre_sucursal
			,BO.KOBO AS bodega
			,BO.NOKOBO as nombre_bodega
			,RIGHT(C.ELISTAVEN,3) as listamodalidad
			,LI.NOKOLT as nombre_lista
            ,C.EMPRESA as empresa
			,CO.RAZON AS razonsocial
			,( CASE WHEN US.KOUS IS NULL THEN '5' ELSE US.TIPO END ) as tipopermiso
			,coalesce(US.VALOR,0) as valorpermiso
    from TABFU         as F  with (nolock) 
    left join CONFIEST as C  with (nolock) on C.MODALIDAD=F.MODALIDAD
    left join CONFIGP  AS CO with (nolock) on CO.EMPRESA =C.EMPRESA
    left join TABBO    as BO with (nolock) on BO.KOBO=C.EBODEGA
    left join TABSU    AS SU with (nolock) on SU.KOSU=C.ESUCURSAL
    left join TABPP    AS LI with (nolock) on LI.KOLT=RIGHT(C.ELISTAVEN,3)
	LEFT JOIN MAEUS    AS US with (nolock) on US.KOUS=F.KOFU AND US.KOOP='TO000006' 
    where upper(F.EMAIL)=upper(@kodigo) 
     and PWFU=@dekey 
     and F.INACTIVO<>1 
     -- and coalesce(C.EMPRESA,'01')='01' ;
	 --
END
go       

-- exec ksp_buscarProductos '','ALA000295','BBA','01P',0,'01','WEB','';
-- exec ksp_buscarProductos '','ALA000306','BBA','01P',0,'01','WEB','';
-- select * from MAEPR where KOPR like 'THO021387%'
IF OBJECT_ID('ksp_buscarProductos', 'P') IS NOT NULL  
    DROP PROCEDURE ksp_buscarProductos;  
GO  
CREATE PROCEDURE ksp_buscarProductos (
    @codproducto   varchar(13)   =  '', 
    @descripcion   varchar(50)   =  '',
    @bodega        char(3)       =  '',
    @listapre      char(3)       =  '',
    @offset        int           =  0 ,   
	@empresa	   char(2)       =  '01',	
	@usuario       char(3)       =  '',
	@codefam	   varchar(14)   =  '' ) 
With Encryption
AS
BEGIN
 
    SET NOCOUNT ON
 
    declare @kodigo     varchar(60);
    declare @descri     varchar(2500);
    declare @xbodega    char(3);
    declare @xlistapre  char(3);
	declare @xempresa   char(2);
	declare @xusuario   char(3);
	declare @sucursal	char(3);
    declare @query      NVARCHAR(max) = '';
    declare @xnokopr    varchar(3500)  = '';
    declare @xkopr      varchar(300)   = '';
    declare @letraN     char(1)        = 'N';
    declare @neto       char(5)        = 'Neto ';
    declare @bruto      char(5)        = 'Bruto';
	declare @paginar	varchar(150)   = '';	
	declare @salida		varchar(400)   = '';

	declare @xcodefam		varchar(400) = '';

    declare @stock			varchar(800) = ' COALESCE(PR.STFI1,0)-coalesce(PR.STOCNV1,0)+coalesce(PR.STOCNV1C,0) > 0 ';
	declare @soloimportados varchar(800) = ''; 
	declare @soloconprecios varchar(800) = '';

	declare @solodesplegar	varchar(60)		= '';
	declare @occ			char(3)			= 'OCC';
    declare @xorden			varchar(250)	= ' ORDER BY PR.KOPR ';
	declare @docdecompra	varchar(250)	= '('+char(39)+'FCC'+char(39)+','+char(39)+'GRC'+char(39)+','+char(39)+'GRI'+char(39)+','+char(39)+'GRD'+char(39)+','+char(39)+'NCC'+char(39)+','+char(39)+'FCT'+char(39)+','+char(39)+'GRP'+char(39)+')),cast(0 as bit)';
 
    set @codproducto    = RTRIM(@descripcion);   -- RTRIM(@codproducto);
    set @descripcion    = RTRIM(@descripcion);
    set @xbodega        = RTRIM(@bodega);
    set @xlistapre      = RTRIM(@listapre);
	set @xempresa		= RTRIM(@empresa);
	set @xusuario		= RTRIM(@usuario);
	--
	select @sucursal = KOSU from TABBO with (nolock) where EMPRESA=@empresa AND KOBO = @bodega;
	--
	set @query += 'with precios ';
	set @query += 'as ( select L.KOPR,TL.MELT,(case when TL.MELT='+char(39)+@letraN+char(39)+' then '+char(39)+@neto+char(39)+' else '+char(39)+@bruto+char(39)+' end) as tipolista,';
	set @query +=             'L.PP01UD,L.DTMA01UD,L.EDTMA01UD,';
	set @query +=	          'L.PP02UD,L.DTMA02UD,L.EDTMA02UD ';
	set @query +=		'from TABPRE  AS L with (nolock) ';
	set @query +=		'inner join TABPP TL  with (nolock) on L.KOLT=TL.KOLT ';
	set @query +=		'where L.KOLT='+char(39)+@listapre+char(39)+' ), ';

	set @query  += 'stoksuc ';
	set @query  += 'as ( select KOPR,sum(STFI1) as fisico,sum(STOCNV1) as pendiente,sum(STOCNV1C) as porllegar ';
	set @query  +=      'from MAEST WITH (NOLOCK) ';
	set @query  +=      'where EMPRESA='+char(39)+@empresa+char(39);
	set @query  +=       ' and KOSU='+char(39)+@sucursal+char(39);
	set @query  +=      'group by KOPR ) ';

    set @query += 'select rtrim(PR.KOPR) as codigo,rtrim(PR.KOPRTE) as codigotec,';
    set @query +=         'rtrim(PR.NOKOPR) AS descripcion,PR.UD01PR as unidad1, PR.RLUD as rtu,';
    set @query +=         'COALESCE(PR.STFI1,    0) as e_fisico_ud1,   COALESCE(SU.fisico,    0) as s_fisico_ud1,   COALESCE(BO.STFI1,    0) as b_fisico_ud1,'; 
	set @query +=         'coalesce(PR.STOCNV1,  0) as e_pendiente_ud1,coalesce(SU.pendiente, 0) as s_pendiente_ud1,COALESCE(BO.STOCNV1,  0) as b_pendiente_ud1,'; 
	set @query +=         'coalesce(PR.STOCNV1C, 0) as e_porllegar_ud1,coalesce(SU.porllegar, 0) as s_porllegar_ud1,coalesce(BO.STOCNV1C, 0) as b_porllegar_ud1,'; 
    set @query +=         'COALESCE(PR.STFI1,0)-coalesce(PR.STOCNV1,0)+coalesce(PR.STOCNV1C,0)     as e_saldo_ud1,'; 
	set @query +=         'coalesce(SU.fisico,0)-coalesce(SU.pendiente,0)+coalesce(SU.porllegar,0) as s_saldo_ud1,'; 
	set @query +=         'COALESCE(BO.STFI1,0)-coalesce(BO.STOCNV1,0)+coalesce(BO.STOCNV1C,0)     as b_saldo_ud1,'; 
    set @query +=         '0.0 as apedir,';
	set @query +=         'cast(0 as bit) as concompras,';
    set @query +=         'BO.KOSU as sucursal,'+char(39)+@bodega+char(39)+' as bodega,( select rtrim(TB.NOKOBO) from TABBO AS TB with (nolock) where TB.KOBO='+char(39)+@bodega+char(39)+' ) as nombrebodega,';
    set @query +=         'L.PP01UD as precio ,round((L.PP01UD-(L.PP01UD*L.DTMA01UD/100)),0) as preciomayor ,L.DTMA01UD as descuentomax ,round(L.PP01UD*L.DTMA01UD/100,0) as dsctovalor ,';
    set @query +=         'upper((case when patindex(''%#%'',reverse(rtrim(L.EDTMA01UD)))>0 then substring(rtrim(L.EDTMA01UD), 1, len(rtrim(L.EDTMA01UD))-patindex(''%#%'',reverse(rtrim(L.EDTMA01UD)))) else rtrim(L.EDTMA01UD) end)) as ecu_max1, ';
    set @query +=         char(39)+'1'+char(39)+' as ud_venta,0.0 as montolinea, 0.00 as dsctovend,';
    set @query +=         'coalesce(rtrim(MA.NOKOMR),'+char(39)+''+char(39)+') as marca,';
    set @query +=         'coalesce(rtrim(SF.NOKOFM),'+char(39)+''+char(39)+') as superfam,';
    set @query +=         'L.tipolista,L.MELT as metodolista,'+char(39)+@xlistapre+char(39)+' as listaprecio ';
    set @query += 'FROM MAEPR         AS PR  WITH (NOLOCK) ';
    set @query += 'inner join MAEPREM AS ME  WITH (NOLOCK) on PR.KOPR=ME.KOPR and ME.EMPRESA='+char(39)+@empresa+char(39)+' ';
	set @query += 'left  join stoksuc AS SU  WITH (nolock) on SU.KOPR = PR.KOPR ';
    set @query += 'left  join MAEST   AS BO  WITH (NOLOCK) on BO.EMPRESA='+char(39)+@empresa+char(39)+' and BO.KOSU='+char(39)+@sucursal+char(39)+' AND BO.KOBO='+char(39)+@bodega+char(39)+' AND BO.KOPR = PR.KOPR ';
    set @query += 'left  join precios AS L   with (nolock) on L.KOPR=PR.KOPR ';
    set @query += 'left  join TABMR   AS MA  with (nolock) on MA.KOMR=PR.MRPR ';
    set @query += 'left  join TABFM   AS SF  with (nolock) on SF.KOFM=PR.FMPR ';
 
	set @xorden  = ' ORDER BY codigo ';
	set @paginar = ' OFFSET '+rtrim(cast(@offset as varchar(5)))+' ROWS FETCH NEXT 20 ROWS ONLY; ';

    -- pasadas por ksp_cambiatodo
    exec ksp_cambiatodo @descripcion, @salida = @descri  OUTPUT ;
    exec ksp_cambiatodo @codproducto, @salida = @kodigo  OUTPUT ;

    set @descri = case when @descri<>''	then @descri else '' end;
    set @kodigo = case when @kodigo<>'' then @kodigo else '' end;

    if ( @descri<>'' and @kodigo<>'' ) begin
		--
		if ( @codefam <> '' ) begin
			-- 
			set @codefam = ltrim(rtrim(@codefam)) + ',';
			exec ksp_TipoGoogle_CODEFAM @codefam,',',@xcodefam output;
		end;
		--
		exec ksp_TipoGoogle 'PR.KOPR',@kodigo, @salida = @xkopr output;
		exec ksp_TipoGoogle 'PR.NOKOPR',@descri, @salida = @xnokopr output;
		set @query = concat( @query, ' WHERE ( ', @xkopr, ' or ',  @xnokopr,' ) and ', @stock, case when @codefam<>'' then ' and '+@xcodefam else '' end, @xorden, @paginar ); 
		-- 
		-- print @query;
        EXECUTE sp_executesql @query;
		--
    end
	else begin
		--
		if ( @codefam <> '' ) begin
			--
			set @codefam = ltrim(rtrim(@codefam)) + ',';
			exec ksp_TipoGoogle_CODEFAM @codefam,',',@xcodefam output;
			--
			set @query = concat( @query, ' WHERE ', @stock, ' and ', @xcodefam, @xorden, @paginar ); 
			-- 
			-- print @xkopr;
			-- print @xnokopr;
			-- print @xcodefam;
			-- print @query;
			EXECUTE sp_executesql @query;
			--
		end;
		--
	end
	--
END
go

IF OBJECT_ID('ksp_crearClientes', 'P') IS NOT NULL 
    DROP PROCEDURE ksp_crearClientes; 
GO
CREATE PROCEDURE ksp_crearClientes (
    @rut varchar(20),
    @nombre varchar(50),
    @direccion varchar(50)='',
    @codcomuna varchar(3)='',
    @codciudad varchar(3)='',
    @email varchar(50),
    @nrocelu varchar(20),
    @giro varchar(100) = '' ) With Encryption
AS
BEGIN
    SET NOCOUNT ON
    --
    declare @Error      nvarchar(250),
            @ErrMsg     nvarchar(2048);
    declare @codigo     varchar(20),
            @rut8       char(13),
            @pos        int,
            @id         int;
    --
    begin try
        set @codigo = replace(ltrim(rtrim( @rut )),'.' ,'');
        --
        SELECT @pos = charindex('-', @codigo );
        if ( @pos <= 0 ) begin
            set @Error = '50410';
            set @ErrMsg = 'Error: rut no está bien escrito, falta guión y dígito verificador';
            THROW @Error, @ErrMsg, 0 ; 
        end
        --
        set @codigo = substring( @codigo, 1, @pos-1 );
        if ( cast(@codigo as int) > 99999999 ) begin
            set @Error = '50415';
            set @ErrMsg = 'Error: rut de cliente es mayor a 99.999.999. Es incorrecto. ';
            THROW @Error, @ErrMsg, 0 ; 
        end
        --
        set @rut8   = right( '00000000' + @codigo, 8 );
        if exists ( select * from MAEEN with (nolock) where ( KOEN = @codigo and TIPOSUC = 'P' ) or RTEN = @rut8 ) begin
            set @Error = '50420';
            set @ErrMsg = 'Error: rut de cliente ( '+@rut+' ) ya existe en la base de clientes';
            THROW @Error, @ErrMsg, 0 ; 
        end
        --
        if not exists ( select * from MAEEN with (nolock) where KOEN = 'CLIENTE_WEB' ) begin
            set @Error = '50400';
            set @ErrMsg = 'Error: no existe CLIENTE_WEB para creación de clientes on-line';
            THROW @Error, @ErrMsg, 0 ; 
        end
        -- buscar la entidad modelo
        select * into #pasoen from MAEEN with (nolock) where KOEN = 'CLIENTE_WEB';
        --
        alter table #pasoen drop COLUMN IDMAEEN
        --
        update #pasoen set KOEN = left(rtrim(@codigo),13) 
                           ,NOKOEN = left(rtrim(@nombre),50)
                           ,NOKOENAMP = left(rtrim(@nombre),100)
                           ,RTEN = rtrim(@rut8)
                           ,GIEN = case when coalesce(@giro,'')='' then GIEN else left(rtrim(@giro),100) end
                           ,SUEN = ''
                           ,TIEN='C'
                           ,TIPOSUC = 'P'
                           ,DIEN = case when coalesce(@direccion,'')='' then DIEN else left(rtrim(@direccion),50) end
                           ,CMEN = case when coalesce(@codcomuna,'')='' then CMEN else left(@codcomuna,3) end
                           ,CIEN = case when coalesce(@codciudad,'')='' then CIEN else left(@codciudad,3) end
                           ,EMAIL = left(@email,50)
                           ,EMAILCOMER = left(@email,50)
                           ,FOEN = left(@nrocelu,20)
                           ,FECREEN = getdate() ;

        -- intentamos insertarlo
        insert into MAEEN select * from #pasoen;

        -- avisamos la creacion
        select cast(1 as bit) resultado, cast(0 as bit) error, 'Cliente creado exitosamente' as mensaje ;
        --
        drop table #pasoen;
        --
    end try
    --
    begin catch
        if (@Error = 0) begin
            set @Error = @@ERROR;
            set @ErrMsg = ERROR_MESSAGE();
        end
        select cast(0 as bit) resultado, cast(1 as bit) error, @ErrMsg as mensaje ;
    end catch
    --
END;
GO

-- exec ksp_construye_top10 '01','01P';
IF OBJECT_ID('ksp_construye_top10', 'P') IS NOT NULL  
    DROP PROCEDURE ksp_construye_top10;  
GO  
CREATE PROCEDURE ksp_construye_top10 ( @empresa char(2), @lista char(3) ) 
With Encryption
AS
BEGIN
    SET NOCOUNT ON
	IF EXISTS (SELECT * FROM sysobjects WHERE name='ktb_ventas12') BEGIN
		drop table ktb_ventas12
	END
	
	declare @fechamovil as datetime = dateadd( dd, -30, getdate() ),
			@fechahoy	as datetime = cast( getdate() as date );
	--
	with ventas as (select top 30 ddo.KOPRCT as codigo
							,sum(ddo.VANELI * (case when ddo.TIDO = 'NCV' then -1 else 1 end) ) as x1
					from MAEDDO as ddo with (nolock)
					inner join MAEEDO as edo with (nolock) on edo.IDMAEEDO = ddo.IDMAEEDO
					WHERE edo.EMPRESA = @empresa
					  and edo.TIDO in ('FCV','BLV','NCV')
					  and edo.FEEMDO > @fechamovil
					group by ddo.KOPRCT 
					order by sum(ddo.VANELI * (case when ddo.TIDO = 'NCV' then -1 else 1 end) ) desc )
	select  rtrim(v.codigo) as codigo
			,rtrim(pr.NOKOPR) as descripcion
			,pr.UD01PR unidad 	
			,pr.STFI1 as stock
			,pre.PP01UD as precio
    into ktb_ventas12
	from ventas as v
	inner join MAEPR as pr  with (nolock) on pr.KOPR = v.codigo and pr.STFI1>0
	left join TABPRE as pre with (nolock) on pre.KOLT = @lista and pre.KOPR = v.codigo and pre.PP01UD>0
	
END
go

-- exec ksp_ventastop10 '01','01P','009','027';
IF OBJECT_ID('ksp_ventastop10', 'P') IS NOT NULL  
    DROP PROCEDURE ksp_ventastop10;  
GO  
CREATE PROCEDURE ksp_ventastop10 ( 
	@empresa 	char(2), 
	@lista 		char(3), 
	@sucursal 	char(3)='',
	@bodega 	char(3)='' )  With Encryption
AS
BEGIN
	--
    SET NOCOUNT ON;
	--
	with precios as ( select L.KOPR,TL.MELT,(case when TL.MELT='N' then 'Neto' else 'Bruto' end) as tipolista,
							 L.PP01UD,L.DTMA01UD,L.EDTMA01UD,
							 L.PP02UD,L.DTMA02UD,L.EDTMA02UD 
					  from TABPRE  AS L with (nolock) 
					  inner join TABPP TL  with (nolock) on L.KOLT=TL.KOLT 
					  where L.KOLT=@lista ), 
	stoksuc as (select KOPR,sum(STFI1) as fisico,sum(STOCNV1) as pendiente,sum(STOCNV1C) as porllegar 
				from MAEST WITH (NOLOCK) 
				where EMPRESA=@empresa
				and KOSU=@sucursal
				group by KOPR )
    select top 12
		   PR.KOPR as codigo,PR.KOPRTE as codigotec,
           rtrim(PR.NOKOPR) AS descripcion,PR.UD01PR as unidad1, PR.RLUD as rtu,
           COALESCE(PR.STFI1,    0) as e_fisico_ud1,   COALESCE(SU.fisico,    0) as s_fisico_ud1,   COALESCE(BO.STFI1,    0) as b_fisico_ud1, 
	       coalesce(PR.STOCNV1,  0) as e_pendiente_ud1,coalesce(SU.pendiente, 0) as s_pendiente_ud1,COALESCE(BO.STOCNV1,  0) as b_pendiente_ud1, 
	       coalesce(PR.STOCNV1C, 0) as e_porllegar_ud1,coalesce(SU.porllegar, 0) as s_porllegar_ud1,coalesce(BO.STOCNV1C, 0) as b_porllegar_ud1, 
           COALESCE(PR.STFI1,0)-coalesce(PR.STOCNV1,0)+coalesce(PR.STOCNV1C,0)     as e_saldo_ud1, 
	       coalesce(SU.fisico,0)-coalesce(SU.pendiente,0)+coalesce(SU.porllegar,0) as s_saldo_ud1, 
	       COALESCE(BO.STFI1,0)-coalesce(BO.STOCNV1,0)+coalesce(BO.STOCNV1C,0)     as b_saldo_ud1, 
           0.0 as apedir,
	       cast(0 as bit) as concompras,
           BO.KOSU as sucursal,@bodega as bodega,( select rtrim(TB.NOKOBO) from TABBO AS TB with (nolock) where TB.KOBO=@bodega ) as nombrebodega,
           L.PP01UD as precio ,round((L.PP01UD-(L.PP01UD*L.DTMA01UD/100)),0) as preciomayor ,L.DTMA01UD as descuentomax ,round(L.PP01UD*L.DTMA01UD/100,0) as dsctovalor ,	
           upper((case when patindex('%#%',reverse(rtrim(L.EDTMA01UD)))>0 then substring(rtrim(L.EDTMA01UD), 1, len(rtrim(L.EDTMA01UD))-patindex('%#%',reverse(rtrim(L.EDTMA01UD)))) 
		               else rtrim(L.EDTMA01UD) 
				  end)) as ecu_max1, 
           '1' as ud_venta,0.0 as montolinea, 0.00 as dsctovend,
           coalesce(MA.NOKOMR,'') as marca,
           coalesce(SF.NOKOFM,'') as superfam,
           L.tipolista,L.MELT as metodolista,@lista as listaprecio,
		   (case when L.MELT='Neto' then L.PP01UD else L.PP01UD/1.19 end ) as precioneto,
		   (case when L.MELT='Neto' then L.PP01UD*0.19 else (L.PP01UD-L.PP01UD/1.19) end ) as iva,
		   (case when L.MELT='Neto' then L.PP01UD*1.19 else L.PP01UD end ) as brutounitario 
	from ktb_ventas12 as v	   
    inner join MAEPR   AS PR  WITH (NOLOCK) on v.codigo = PR.KOPR 
    inner join MAEPREM AS ME  WITH (NOLOCK) on PR.KOPR=ME.KOPR and ME.EMPRESA=@empresa
	left  join stoksuc AS SU  WITH (nolock) on SU.KOPR = PR.KOPR 
    left  join MAEST   AS BO  WITH (NOLOCK) on BO.EMPRESA=@empresa and BO.KOSU=@sucursal AND BO.KOBO=@bodega AND BO.KOPR = PR.KOPR 
    left  join precios AS L   with (nolock) on L.KOPR=PR.KOPR 
    left  join TABMR   AS MA  with (nolock) on MA.KOMR=PR.MRPR 
    left  join TABFM   AS SF  with (nolock) on SF.KOFM=PR.FMPR 
 	ORDER BY codigo ;
	--	
	/*
	select	top 12
			rtrim(v.codigo) as codigo
			,RTRIM(v.descripcion) as descripcion 
			,v.unidad 	
			,pr.STFI1 as stock
			,pre.PP01UD as precio
	*/
	--
END
go

--declare @ss varchar(100);
--exec ksp_StrToken 'papa;mama;hijo;',3,';',@salida = @ss output;
--print @ss
 
IF OBJECT_ID('ksp_StrToken', 'P') IS NOT NULL  
    DROP PROCEDURE ksp_StrToken;  
GO  
create procedure ksp_StrToken ( 
        @cadena  varchar(2500), 
        @pos     int, 
        @token   varchar(10),
        @salida  varchar(2500) OUTPUT ) 
With Encryption
AS 
BEGIN
    set NOCOUNT ON
 
    declare @i      int, @j int, @k int, @largo int;
    declare @xpos   int;
    declare @car    char(1);
    declare @dev    varchar(2500);
 
    set @cadena = RTRIM( @cadena );
    set @largo  = LEN( @cadena );
    set @i      = 0;
    set @j      = 1;
    set @k      = 0;
 
    set @dev    = '';
    set @xpos   = 0
 
    WHILE ( @i <= @largo )
    BEGIN
        --
        set @i      = @i + 1;
        set @car    = substring( @cadena, @i, 1 );
        set @k      = @k + 1;
 
        --
        if @car = @token        -- encontró un token
        begin
            set @xpos += 1;     
            if @xpos = @pos     -- posicion encontrada es la buscada?
                begin
                    if @k > 1
                        set @dev = substring( @cadena, @j, @k-1 );      
                    else
                        set @dev = '';      
                    --
                    set @salida = @dev;
                    set @i = @largo+1; -- ya se encontró, salir !!
                end
            else
                begin
                    set @k  = 0;
                    set @j  = @i+1;
                end
        end
     END
     select @salida = @dev;
     RETURN
END 
GO

IF OBJECT_ID('ksp_cambiatodo', 'P') IS NOT NULL  
    DROP PROCEDURE ksp_cambiatodo;  
GO  
create procedure ksp_cambiatodo ( 
       @dato varchar(2500), 
       @salida varchar(2500) OUTPUT ) With Encryption
AS 
BEGIN
    declare @i      int;
    declare @largo  int;
    declare @car    char(1);
    declare @dev    varchar(2500);
 
    set @dato   = RTRIM( @dato );
    set @largo  = LEN( @dato );
    set @i      = 1;
    set @dev    ='';
 
    WHILE ( @i <= @largo )
    BEGIN
        set @car = substring( @dato, @i, 1 );
        if @car = ' ' OR @car = '%' OR ( @car >= '0' AND @car <= '9' )
            set @dev += @car;
        else
            set @dev += '['+UPPER(@car)+LOWER(@car)+']';
        set @i += 1;
     END
     select @salida = @dev;
     RETURN
END 
go

IF OBJECT_ID('ksp_TipoGoogle', 'P') IS NOT NULL  
    DROP PROCEDURE ksp_TipoGoogle;  
GO  
 
create procedure ksp_TipoGoogle ( 
        @campo   varchar(20),   
        @cdescri varchar(2500), 
        @salida varchar(2500) OUTPUT ) With Encryption
AS 
BEGIN
    declare @ctoken     varchar(2500);
    declare @cdev       varchar(2500);
    declare @ccadena    varchar(2500);
    declare @n          int;
 
    set @campo      = LTRIM(RTRIM( @campo ));
    set @cdescri    = LTRIM(RTRIM( @cdescri ));
 
    set @ccadena    = @cdescri;
    set @n          = 1;
    set @cdev       = '';
 
    exec ksp_StrToken @ccadena,@n,' ',@salida = @ctoken output;
 
    WHILE @ctoken <> '' 
    BEGIN
        --
        if @n = 1
            set @cdev = @cdev + ' ';
        else
            set @cdev = @cdev + ' AND ';
        --   
        set @cdev += CONCAT( @campo,' LIKE ',char(39),'%', RTRIM(@ctoken), '%', char(39), ' ');
        set @n = @n + 1;
        exec ksp_StrToken @ccadena,@n,' ',@salida = @ctoken output;
     END
     select @salida = @cdev;
     RETURN
END; 
go
 

/*
select getdate(), dateadd( dd, 30, getdate())
declare @xx datetime = getdate()
exec ksp_sumaMes @xx, 0, 30, @xx output 
print @xx;
  
select * from TABPP

*/
IF OBJECT_ID('ksp_sumaMes', 'P') IS NOT NULL  
    DROP PROCEDURE ksp_sumaMes;  
GO  
CREATE PROCEDURE ksp_sumaMes (
    @fecha		 datetime, 
	@n			 int = 0,
    @nDiasVenci  int = 0,
	@fechaultima datetime output ) With Encryption
as
begin
    SET NOCOUNT ON

	declare @veces int = 1
			
	while @veces <= @n
	begin
		set @fecha = DATEADD( dd, ( case when @nDiasVenci=0 then 30 else @nDiasVenci end), @fecha );
		set @veces += 1;
	end
	set @fechaultima = @fecha;
end;
go


--declare @nro char(10) = '0000000010';
--exec ksp_NumeroDocumento_v1 '01','1CM00','NVV', @nro output ;
--print @nro

IF OBJECT_ID('ksp_NumeroDocumento_v1', 'P') IS NOT NULL  
    DROP PROCEDURE ksp_NumeroDocumento_v1;  
GO  
CREATE PROCEDURE ksp_NumeroDocumento_v1 ( 
       @empresa		char(2) = '01', 
	   @modalidad	char(5) = '',
	   @tipodoc		char(3),
	   @numero		char(10) output ) With Encryption
AS
BEGIN
 
	declare @campo		char(3),
			@campolsr	varchar(10),
			@ndev		char(10),
			@xelmodo    char(5),
			@maxnudo	char(10),
			@query      NVARCHAR(2500);		

	set @xelmodo	= @modalidad
	set @campo		= UPPER(@tipodoc) ;
	set @campolsr	= UPPER(@tipodoc)+'LSR' ;

	SET NOCOUNT ON
	--
	set @query = 'select @ndev = '+@campo+' from CONFIEST where EMPRESA = '+char(39)+@empresa+char(39)+' and MODALIDAD = '+char(39)+@xelmodo+char(39)+' ;';
	--
	EXECUTE sp_executesql @query,N' @ndev char(10) output ',@ndev output;

	-- si esta vacio debe tomar valor de configuracion central
	if (coalesce(@ndev,'') = '' )
	begin
		set @xelmodo = char(5)+' '+char(5)+' '+char(5);
		--
		if exists ( select * from CONFIEST with (nolock) where EMPRESA = @empresa and MODALIDAD = @xelmodo ) begin
			set @query = 'select @ndev = '+@campo+' from CONFIEST where EMPRESA = '+char(39)+@empresa+char(39)+' and MODALIDAD = '+char(39)+@xelmodo+char(39)+' ;';
			EXECUTE sp_executesql @query,N' @ndev char(10) output ',@ndev output;
			--
			set @numero = @ndev ;
			--
		end
		else begin
			-- no se encontro numero en confiest
			set @numero = '0000000000' ;
		end
	end
	else begin
		-- de lo contrario se revisa la configuracion de estacion correspondiente
		if ( @ndev = '0000000000' ) begin 
			if ( @campo = 'GDV' ) begin
                select @maxnudo = coalesce( max(NUDO),'0000000000')
				from MAEEDO with (nolock)
                where TIDO IN ('GDV','GDD','GDP','GTI')
				  and EMPRESA = @empresa
			end
			else begin
                select @maxnudo = coalesce( max(NUDO),'0000000000')
				from MAEEDO with (nolock)
                where TIDO=@campo
				  and EMPRESA = @empresa
			end
            --
			exec ksp_valsgtecar @maxnudo, @numero output ;
			--
			-- existen pendientes con numeros mayores o iguales?
			if ( @campo = 'NVV' or @campo = 'OCC' ) and exists ( select * from KASIEDO with (nolock) where EMPRESA=@empresa and TIDO=@campo and LIBRO=@numero )	begin
                select @maxnudo = coalesce( max(LIBRO),'0000000000')
				from KASIEDO with (nolock)
                where TIDO=@campo
				  and EMPRESA = @empresa ;
                --
				exec ksp_valsgtecar @maxnudo, @numero output ;
				--
			end
		end
		else begin
		-- el numero que esta es el que deberia servir
            --
			set @numero = @ndev;
			--
		end
		-- verificar si existe... pero devuelvo el mismo ... y el grabador lo desecha
		if exists ( select * from MAEEDO with (nolock) where EMPRESA=@empresa and TIDO=@campo and NUDO=@numero ) begin
			-- nada pasa
			set @numero = @numero ;	
		end
   	end

END;
go

/*
declare @segundos int = 0;
exec ksp_HoraGrab @segundos output ;
print @segundos  
*/
IF OBJECT_ID('ksp_HoraGrab', 'P') IS NOT NULL  
    DROP PROCEDURE ksp_HoraGrab;  
GO  
CREATE PROCEDURE ksp_HoraGrab (	@segundos int output ) With Encryption
as
begin
    SET NOCOUNT ON
	--
	declare @hora	varchar(50),
			@x		varchar(50),
			@l		int = 0,
			@y		varchar(50),
			@m		int = 0,
			@h		int = 0,
			@s		int = 0
	--
	SELECT @hora = CONVERT( VARCHAR(45), CURRENT_TIMESTAMP, 9 ) ;
	--
	set @x = rtrim( @hora );
	set @l = len( @x );
	set @y = substring( @x, @l-1,2); -- PM,AM
	set @m = cast( substring( @x, @l-10,2) as int ); -- minutos
	set @h = cast( substring( @x, @l-13,2) as int ); -- horas
	set @s = cast( substring( @x, @l-7,2)  as int);  -- segundos
	--			
	if UPPER(@y) = 'PM' and @h<>12
	begin
		set @segundos = ((@h + 12) * 3600) + ( @m * 60 ) + @s;
	end
	else
	begin
		set @segundos = (@h * 3600) + ( @m * 60 ) + @s;
	end
end;
go 


/*
declare @car char(10) = 'W-00000001';
exec ksp_valsgtecar @car, @car output ;
print @car
*/
IF OBJECT_ID('ksp_valsgtecar', 'P') IS NOT NULL  
    DROP PROCEDURE ksp_valsgtecar;  
GO  
CREATE PROCEDURE ksp_valsgtecar ( 
       @expresion	 char(10),  
	   @numerosalida char(10) output ) With Encryption
as
begin
    SET NOCOUNT ON
	--
	declare @x		int = 0,
			@j		int = len(@expresion),
			@i		int = 1,
			@nlargo	int = len(@expresion),
			@parten	varchar(10),
			@partec varchar(10)

	while ( @i <= @nlargo )
	begin
		if ( CHARINDEX( substring( @expresion, @j, 1 ),'0123456789') <> 0 ) 
		begin
			set @x = @j;
		end
		set @i += 1;
		set @j -= 1;
	end
	
	if ( @x > 0 )
		begin
		   set @parten = substring( @expresion, @x, 10-@x+1 );
		   set @parten = right( '0000000000' + cast((cast( @parten as int )+1) as varchar(10)), @nlargo-@x+1 ) ;
		   set @partec = left(@expresion,@x-1);
		   set @numerosalida = @partec + @parten ;
		end
	else
		begin 
		   set @numerosalida = 'ERROR-0001' ;
		end
END;
go  

IF OBJECT_ID('ksp_motivo', 'P') IS NOT NULL  begin
    DROP PROCEDURE ksp_motivo;  
end;
go
create procedure ksp_motivo ( @documento char(3) )
with encryption
as 
begin
	 select KOCARAC as codigo,NOKOCARAC as descripcion 
	 from TABCARAC with (nolock)
	 where KOTABLA = 'MOTIVOS'+@documento
	 order by KOCARAC ; 
end;
go

-- exec ksp_buscarCotizaciones '2','01','V03'
IF OBJECT_ID('ksp_buscarCotizaciones', 'P') IS NOT NULL  begin
    DROP PROCEDURE ksp_buscarCotizaciones;  
end;
go
create procedure ksp_buscarCotizaciones ( @cliente char(13), @empresa char(2), @usuario char(3) )
with encryption
as 
begin
	select edo.IDMAEEDO as id, edo.TIDO as tipo, edo.NUDO as numero,cast(edo.FEEMDO as date) as fecha, edo.VABRDO as bruto
	from MAEEDO as edo with (nolock)
	left join MAEEN as en with (nolock) on en.KOEN = edo.ENDO and en.TIPOSUC = 'P'
	where edo.EMPRESA = @empresa
	  and edo.ENDO = @cliente 
	  and edo.TIDO = 'COV'
	  and edo.ESDO not in ('C','N')
	order by fecha;
end;
go

-- exec ksp_buscarCotizacion 10237028 ;
IF OBJECT_ID('ksp_buscarCotizacion', 'P') IS NOT NULL  begin
    DROP PROCEDURE ksp_buscarCotizacion;  
end;
go
create procedure ksp_buscarCotizacion ( @id int )
with encryption
as 
begin
	select	edo.IDMAEEDO as id, ddo.IDMAEDDO as id_detalle,ddo.NULIDO as linea,
			ddo.KOPRCT as codigo, ddo.NOKOPR as descripcion,
			ddo.BOSULIDO as bodega,bo.NOKOBO as nombre_bodega,
			ddo.KOFULIDO as vendedor,fu.NOKOFU as nombre_vend,
			ddo.PPPRNE as neto_unitario,ddo.PPPRBR as bruto_unitario,
			(case when ddo.UDTRPR=1 then ddo.CAPRCO1-ddo.CAPRAD1-ddo.CAPREX1 else ddo.CAPRCO1-ddo.CAPRAD1-ddo.CAPREX1 end ) as cantidad,
			(case when ddo.UDTRPR=1 then ddo.UD01PR else ddo.UD02PR end ) as unidad
	from MAEDDO as ddo with (nolock)
	inner join MAEEDO as edo with (nolock) on edo.IDMAEEDO = ddo.IDMAEEDO
	left join TABBO as bo with (nolock) on bo.KOBO = ddo.BOSULIDO
	left join TABFU as fu with (nolock) on fu.KOFU = ddo.KOFULIDO 
	where edo.IDMAEEDO = @id
	  and ddo.CAPRCO1-ddo.CAPRAD1-ddo.CAPREX1 > 0
	order by linea;
end;
go
