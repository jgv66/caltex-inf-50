
IF OBJECT_ID('ksp_superfam', 'P') IS NOT NULL  
    DROP PROCEDURE ksp_superfam;  
GO;
create procedure ksp_superfam 
with encryption
as 
begin
	 select KOFM as superfamilia, NOKOFM as descripcion 
	 from TABFM with (nolock)
	 where KOFM in ('ACE','FER','TER','MAD','MAT') 
	 order by KOFM ; 
end;
go

IF OBJECT_ID('ksp_familias', 'P') IS NOT NULL  
    DROP PROCEDURE ksp_familias;  
GO;  
create procedure ksp_familias 
with encryption
as 
begin
	select KOFM as superfamilia, KOPF as familia, NOKOPF as descripcion 
	from TABPF with (nolock)
	where KOFM in ('ACE','FER','TER','MAD','MAT') 
	order by KOFM,KOPF ;  
end;
go

IF OBJECT_ID('ksp_subfamilias', 'P') IS NOT NULL  
    DROP PROCEDURE ksp_subfamilias;  
GO;  
create procedure ksp_subfamilias 
with encryption
as 
begin
	select KOPF as familia, KOHF as subfamilia, NOKOHF as descripcion 
	from TABHF with (nolock) 
	where KOFM in ('ACE','FER','TER','MAD','MAT')  
	order by KOFM,KOPF,KOHF ;
end;
go

