﻿
IF OBJECT_ID('ksp_LeerYGuardarXML_NVV', 'P') IS NOT NULL  
	DROP PROCEDURE ksp_LeerYGuardarXML_NVV;  
GO
--  
CREATE PROCEDURE ksp_LeerYGuardarXML_NVV ( @xml XML ) With Encryption
AS
BEGIN
    -- SET NOCOUNT ON;
	--
	declare @id_ktp		int      = 0, 
			@nrodoc		char(10) = '', 
			@idreal		int      = 0 , 
			@Error		nvarchar(250) , 
			@ErrMsg		nvarchar(2048), 
			@mydoc		xml,
			@i			int,
			@nuvecr		int,
			@dias1ven	int,
			@diasvenci	int,
			@xtido		char(3) = 'NVV';
	--
	declare @metodolt		char(1),
			@meardo			char(1),
			@iva			decimal(18,5),
			@sudo			char(3),
			@luvt			char(10),
			@listaactiva	char(8),
			@monedaprecio	char(3),
			@tipomonedapre	char(1),
			@cpen		 varchar(40);
	--
	declare @linea 			int,
			@sucursal 		char(3),
			@bodega			char(3),
			@codigo			char(13),
			@unidad_tr		int,
			@cantidad1		decimal(18,5),
			@cantidad2		decimal(18,5),
			@listaprecio	char(3),
			@metodolista	char(1),
			@precio			decimal(18,5),
			@observacion	char(50),
			@KOPR			char(13);
	--
	declare @empresa		char(2),
			@cliente		char(13),
			@suc_cliente	char(10),
			@vendedor		char(3),
			@fechaemision   smalldatetime, 
			@modalidad		char(5) = 'M2VT4',   -- ejemplo de modalidad
			@obs			varchar(250);
	-- <Entidad>
	declare @t_entidad table(	Empresa_erp			char(2)		null,
								Empresa				varchar(80) null,
								Rut					varchar(20)	null,
								Entidad				char(13)	null,
								Sucursal_entidad	char(10)	null,
								Nombre				varchar(50)	null );
	-- <Movimiento_solicitado>
	declare @t_movsol table(	Documento_solicitado		char(3)		null, 
								Numero_documento_solicitado	char(20)	null,
								Orden_compra				varchar(20)	null,
								Nutransmi					varchar(20)	null,
								Fecha_movimiento			datetime	null,
								Fecha_creacion				datetime	null,
								Fecha_entrega_solicitada	datetime	null,
								Empresa_erp					char(2)		null,
								Modalidad					char(5)		null,
								Vendedor					char(3)		null,
								Motivo						char(10)	null,
								Notas						varchar(250) null );
	-- <Detalle_movimiento_solicitado>
	declare @t_detalle table(	Linea						int				null,
								Fecha_entrega_solicitada	datetime		null,
								Bodega						char(3)			null,
								Producto					varchar(20)		null,
								Descripcion					varchar(50)		null,
								Cantidad					decimal(18,5)	null,
								Precio						decimal(18,5)	null,
								Descuento					decimal(18,5)	null );
	BEGIN TRY ;  

		-- traspasar el XML a una variable 
		set @mydoc = @xml;

		-- rescata los datos del XML y los prepara para ser leidos
		exec sp_xml_preparedocument @i output, @mydoc;

		-- <Entidad>
		insert into @t_entidad
		select * 
		from OPENXML(@i,'/Gestion/Entidad',2)
		WITH (	Empresa_erp			char(2)		, 
				Empresa				varchar(80)	, 
				Rut					varchar(20)	,
				Entidad				char(13)	,
				Sucursal_entidad	char(10)	, 
				Nombre				varchar(50)	);  
		--
		set  @Error = @@ERROR
		if ( @Error <> 0 ) begin
			set @ErrMsg = ERROR_MESSAGE();
			THROW @Error, @ErrMsg, 0 ;  
		end				
		--
		-- select * from @t_entidad;
		select @empresa=Empresa_erp From @t_entidad;

		-- <Movimiento_solicitado>  
		insert into @t_movsol
		select * 
		from OPENXML(@i,'/Gestion/Movimiento_solicitado',2)
		WITH (	Documento_solicitado		char(3)		, 
				Numero_documento_solicitado	char(20)	, 
				Orden_compra				varchar(20)	,
				Nutransmi					varchar(20)	,
				Fecha_movimiento			datetime	,
				Fecha_creacion				datetime	,
				Fecha_entrega_solicitada	datetime	,
				Empresa_erp					char(2)		, 
				Modalidad					char(5)		,
				Vendedor					char(3)		,
				Motivo						char(10)	,
				Notas						varchar(250) );
		--
		set  @Error = @@ERROR
		if ( @Error <> 0 ) begin
			set @ErrMsg = ERROR_MESSAGE();
			THROW @Error, @ErrMsg, 0 ;  
		end				
		-- select * from @t_movsol; 

		-- <Detalle_movimiento_solicitado>
		insert into @t_detalle
		select * 
		from OPENXML(@i,'/Gestion/Detalle_movimiento_solicitado',2)
		WITH (	Linea						int			  ,
				Fecha_entrega_solicitada	datetime	  ,	 
				Bodega						char(3)		  ,
				Producto					varchar(20)	  ,
				Descripcion					varchar(50)	  ,
				Cantidad					decimal(18,5) ,
				Precio						decimal(18,5) ,
				Descuento					decimal(18,5) );  
		--
		set  @Error = @@ERROR
		if ( @Error <> 0 ) begin
			set @ErrMsg = ERROR_MESSAGE();
			THROW @Error, @ErrMsg, 0 ;  
		end				
		-- select * from @t_detalle

		-- >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
		-- revisar datos desde el XML antes de trabajar
		-- >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
		select top 1 @modalidad=Modalidad from @t_movsol;
		if ( coalesce(@modalidad,'')= '' or not exists ( select * from CONFIEST with (nolock) where EMPRESA=@empresa and MODALIDAD=@modalidad ) ) begin
			set @Error	= '50299';
			set @ErrMsg = 'Modalidad ('+coalesce(@modalidad,'')+') no existe';
			THROW @Error, @ErrMsg, 0 ;  
		end
		--
		select @bodega=EBODEGA,@listaprecio=right(ELISTAVEN,3) from CONFIEST with (nolock) where EMPRESA=@empresa and MODALIDAD=@modalidad; 
		--
		if exists ( select * from TABBO WHERE KOBO=@bodega and EMPRESA=@empresa ) begin
			select top 1 @sucursal=KOSU from TABBO where KOBO=@bodega and EMPRESA=@empresa ;
			if ( coalesce(@sucursal,'') = '' ) begin
				set @Error	= '50301';
				set @ErrMsg = 'Sucursal rescatada por bodega ('+coalesce(@bodega,'')+') no puede estar vacia';
				THROW @Error, @ErrMsg, 0 ;  
			end
			--
		end
		else begin
			set @Error	= '50302';
			set @ErrMsg = 'Bodega ('+coalesce(@bodega,'')+') debe existir en ERP';
			THROW @Error, @ErrMsg, 0 ;  
		end	
		-- metodo de lista de precios segun modalidad
		select top 1 @metodolt = MELT 
		from TABPP with (nolock)
		where KOLT = @listaprecio; 

		-- documento debe existir
		select @meardo=coalesce(MEARDO,'') from TABTIDO with (nolock) WHERE TIDO=@xtido ;
		if ( @meardo is null or @meardo='' ) BEGIN
			set @Error	= '50303';
			set @ErrMsg = 'Tipo de documento (NVV) no existe en la tabla de documentos';
			THROW @Error, @ErrMsg, 0 ;  
		END
		-- empresa debe existir
		select @iva=coalesce(IVAPAIS,0) from CONFIGP with (nolock) where EMPRESA=@empresa ;
		if ( @iva is null or @iva=0 or @empresa is null or @empresa='' ) BEGIN
			set @Error	= '50304';
			set @ErrMsg = 'Empresa ('+coalesce(@empresa,'')+') no existe en CONFIGP';
			THROW @Error, @ErrMsg, 0 ;  
		END
		-- la modalidad debe existir
		select @sudo=coalesce(ESUCURSAL,''),@luvt=coalesce(LUVTVEN,''),@listaactiva=coalesce(ELISTAVEN,'') 
		from CONFIEST with (nolock) 
		where EMPRESA=@empresa 
		  and MODALIDAD=@modalidad ; 
		--
		if ( @sudo is null or @sudo='' or @listaactiva is null or @listaactiva='' or @empresa is null or @empresa='' ) BEGIN
			set @Error	= '50305';
			set @ErrMsg = 'Empresa ('+coalesce(@empresa,'')+'/'+coalesce(@modalidad,'')+') no existe en CONFIGP';
			THROW @Error, @ErrMsg, 0 ;  
		END
		-- lista de precios vacia ?
		select @monedaprecio=coalesce(MOLT,''),@tipomonedapre=coalesce(TIMOLT,''),@metodolista=coalesce(MELT,'') 
		from TABPP with (nolock) 
		WHERE 'TABPP'+KOLT=@listaactiva ;
		if ( @listaactiva is null or @listaactiva='' ) BEGIN
			set @Error	= '50306';
			set @ErrMsg = 'Lista de Precios vacia';
			THROW @Error, @ErrMsg, 0 ;  
		END
		-- >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
		-- declaraciones para validar <Entidad>
		-- >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
		declare @_emp char(2),
				@_ent char(13),
				@_suc char(10);
		select @_emp = Empresa_erp, @_ent = Entidad, @_suc = Sucursal_entidad From @t_entidad;
		--
		if ( @_emp is null or @_emp<>'01' ) BEGIN
			set @Error	= '50001';
			set @ErrMsg = 'Empresa ('+coalesce(@_emp,'')+') no es la esperada (01)';
			THROW @Error, @ErrMsg, 0 ;  
		END
		if ( @_ent is null or not exists ( select * from MAEEN with (nolock) where KOEN=@_ent and TIPOSUC='P' ) ) BEGIN
			set @Error	= '50002';
			set @ErrMsg = 'Entidad ('+coalesce(@_ent,'')+') no existe';
			THROW @Error, @ErrMsg, 0 ;  
		END
		if not exists ( select * from MAEEN with (nolock) where KOEN=@_ent and SUEN=@_suc ) BEGIN
			set @Error	= '50003';
			set @ErrMsg = 'Entidad/Sucursal no existe';
			THROW @Error, @ErrMsg, 0 ;  
		END
		-- >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
		-- declaraciones para revisar <Movimiento_solicitado>
		-- >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
		declare @_res char(3),
				@_bod char(3),
				@_eje char(3),
				@_usu char(3),
				@_ems char(13);
		select @_emp=Empresa_erp,@_ems=@_ent,@_eje=Vendedor from @t_movsol;
		select @_bod=EBODEGA from CONFIEST with (nolock) where EMPRESA=@empresa and MODALIDAD=@modalidad; 
		--
		if ( @_emp is null or @_emp<>'01' ) BEGIN
			set @Error	= '50004';
			set @ErrMsg = 'Empresa ('+coalesce(@_emp,'')+') no es la esperada (01)';
			THROW @Error, @ErrMsg, 0 ;  
		END
		if ( @_ent is null or not exists ( select * from MAEEN with (nolock) where KOEN=@_ent and TIPOSUC='P' ) ) BEGIN
			set @Error	= '50005';
			set @ErrMsg = 'Entidad ('+coalesce(@_ent,'')+') no existe';
			THROW @Error, @ErrMsg, 0 ;  
		END
		if (  @_eje is null or @_eje='' or not exists ( select * from TABFU with (nolock) where KOFU=@_eje ) ) BEGIN
			set @Error	= '50007';
			set @ErrMsg = 'Vendedor ('+coalesce(@_eje,'')+') no existe en sistema';
			THROW @Error, @ErrMsg, 0 ;  
		END
		-- >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
		-- declaraciones para validar <Detalle_movimiento_solicitado>
		-- >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
		declare @_lin  int,
				@_pro  varchar(20),
				@_out  decimal(18,5),
				@_inn  decimal(18,5),
				@_pre  decimal(18,5),
				@_edm  char(2);
		IF ( (SELECT CURSOR_STATUS('global', 'detalle_cursor')) = 1 ) BEGIN
			CLOSE detalle_cursor		
			DEALLOCATE detalle_cursor
		END	
		--
		DECLARE detalle_cursor CURSOR FORWARD_ONLY STATIC READ_ONLY
		FOR select Linea,case when coalesce(Bodega,'')='' then @bodega else Bodega end, Producto, Cantidad, Precio
		from @t_detalle as d
		--
		OPEN detalle_cursor  
		--
		FETCH NEXT FROM detalle_cursor INTO @_lin, @_bod, @_pro, @_out, @_pre ;
		--
		WHILE ( @@FETCH_STATUS = 0 ) BEGIN
			--
			set @Error  = 0;
			set @ErrMsg = '';
			--
			if ( @_lin is null or @_lin='' ) BEGIN
				set @Error	= '50100';
				set @ErrMsg = '<Detalle_movimiento_solicitado><Linea> vacía';
				THROW @Error, @ErrMsg, 0 ;  
			END
			-- bodega sucursal para la empresa deben existir
			if not exists ( select * from TABBO with (nolock) where EMPRESA=@_emp and KOSU=@sucursal AND KOBO=@_bod ) BEGIN
				set @Error	= '50101';
				set @ErrMsg = 'Empresa/Sucursal/Bodega ('+coalesce(@_emp,'')+'/'+coalesce(@sucursal,'')+'/'+coalesce(@_bod,'')+') no existe';
				THROW @Error, @ErrMsg, 0 ;  
			END
			-- producto debe existir
			if not exists ( select * from MAEPR with (nolock) where KOPR=@_pro ) BEGIN
				set @Error	= '50102';
				set @ErrMsg = 'Codigo de producto ('+coalesce(@_pro,'')+') no existe';
				THROW @Error, @ErrMsg, 0 ;  
			END
			-- producto debe existir para la empresa
			if not exists ( select * from MAEPREM with (nolock) where EMPRESA=@_emp and KOPR=@_pro ) BEGIN
				set @Error	= '50103';
				set @ErrMsg = 'Codigo de producto ('+coalesce(@_pro,'')+') no existe en la empresa ('+coalesce(@_emp,'')+')';
				THROW @Error, @ErrMsg, 0 ;  
			END
			-- precio debe ser mayor q cero
			if ( @_pre is null or @_pre = 0 ) BEGIN
				set @Error	= '50104';
				set @ErrMsg = 'Precio del producto ('+coalesce(@_pro,'')+') en cero, vacìo o no definido';
				THROW @Error, @ErrMsg, 0 ;  
			END
			--
			FETCH NEXT FROM detalle_cursor INTO @_lin, @_bod, @_pro, @_out, @_pre ;
			--
		END
		CLOSE detalle_cursor  
		DEALLOCATE detalle_cursor  
		--
		BEGIN TRANSACTION ;
			-- >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> GRABACION EN ENCABEZADO 
			insert	into 	ktp_encabezado (empresa,cliente,suc_cliente,vendedor,fechaemision,monto,observacion,motivo,tdoc_resp,ndoc_resp,modalidad,valido,fechaentrega,horainicio,horafinal,nutransmi) 
					values ((select top 1 Empresa_erp				from @t_entidad),
							(select top 1 Entidad					from @t_entidad),
							coalesce((select top 1 Sucursal_entidad	from @t_entidad),''),  	-- 
							coalesce((select top 1 Vendedor			from @t_movsol ),''),		-- vendedor
							(select top 1 Fecha_movimiento			from @t_movsol ),			-- fecha documento
							0,																			-- monto 
							coalesce((select top 1 Notas			from @t_movsol ),''),		-- observaciones
							coalesce((select top 1 Motivo			from @t_movsol ),''),		-- MOTIVO
							'OC',																-- tipo de documento respaldo
							coalesce((select top 1 Orden_compra		from @t_movsol ),''),		-- numero de documento respaldo
							@modalidad,															-- modalidad
							'', 									   							-- valido ????
							(select top 1 Fecha_entrega_solicitada	from @t_movsol ),
							(SELECT DATEPART(HOUR,GETDATE())*3600 + DATEPART(MINUTE,GETDATE()) * 60 + DATEPART(SECOND,GETDATE()) ),
							(SELECT DATEPART(HOUR,GETDATE())*3600 + DATEPART(MINUTE,GETDATE()) * 60 + DATEPART(SECOND,GETDATE()) ),
							coalesce((select top 1 Nutransmi from @t_movsol ),'') );		-- indicador de origen totem o tablet
			set @Error = @@ERROR
			if ( @Error <> 0 ) begin
				set @ErrMsg = ERROR_MESSAGE();
				THROW @Error, @ErrMsg, 0 ;  
			end	
			-- >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> ID DE GRABACION
			select @id_ktp = @@IDENTITY ;
			-- >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> GRABACION EN DETALLE
			insert into ktp_detalle (id_preventa,linea, lin_origen, sucursal,  bodega,  codigo,   unidad_tr,unidad1,unidad2,cantidad1,			cantidad2, listaprecio, metodolista,precio,porcedes,              descuentos,                                                           porcerec,recargos,observacion,valido) 
			select                   @id_ktp,    Linea, '',         @sucursal,(case when coalesce(Bodega,'')='' then @bodega else Bodega end), Producto, 1,        '',     '',     coalesce(Cantidad,0),0,		   @listaprecio,@metodolt,  Precio,Coalesce(Descuento,0), (coalesce(Cantidad,0)*Precio)*( 1 - ( Coalesce(Descuento,0) / 100 ) ),0,       0,       '',         ''
			from @t_detalle
			order by Linea;
			--
			set @Error = @@ERROR
			if ( @Error <> 0 ) begin
				set @ErrMsg = ERROR_MESSAGE();
				THROW @Error, @ErrMsg, 0 ;  
			end	
			-- >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> UPDATE EN DETALLE SI EXISTEN DESCUENTOS    jgv 06/02/2020
			/*
			update ktp_detalle set descuentos=(cantidad1*precio)*( 1 - ( porcedes / 100 ) ) 
			where id_preventa = @id_ktp ;  
			--
			set @Error = @@ERROR
			if ( @Error <> 0 ) begin
				set @ErrMsg = ERROR_MESSAGE();
				THROW @Error, @ErrMsg, 0 ;  
			end
			*/	
			-- >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> UPDATE EN ENCABEZADO 
			update ktp_encabezado set monto=( select sum((d.cantidad1*d.precio)-d.descuentos) 
											  from ktp_detalle as d 
											  where d.id_preventa=ktp_encabezado.id_preventa ) 
			where id_preventa = @id_ktp ;  
			set @Error = @@ERROR
			if ( @Error <> 0 ) begin
				set @ErrMsg = ERROR_MESSAGE();
				THROW @Error, @ErrMsg, 0 ;  
			end	
			-- >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> SI LLEGAMOS HASTA AQUI, PODREMOS GENERAR DOCUMENTO
			if exists ( select * from ktp_detalle where id_preventa=@id_ktp ) begin
				exec ksp_grabaDocumentoXML_NVV @xtido, @id_ktp, @Error output, @ErrMsg output, @nrodoc output, @idreal output ;  
				if ( @Error<>0 ) THROW @Error, @ErrMsg, 0 ;
			end
			else begin
				-- error en el sp de grabacion?
				if (@Error<>0) THROW @Error, @ErrMsg, 0 ;  
			end
		-- >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> COMMIT
		if ( @@TRANCOUNT > 0 ) begin
			COMMIT TRANSACTION ;
			select 'ok' as resultado, @nrodoc as numero, @id_ktp as id, @idreal as idreal ;  
		end
		else begin
			select 'error' as resultado,'' as numero, @ErrMsg as el_error, @Error as id_error  ;  
		end;
		--
	END TRY 
	--

	-- >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> SI EXISTEN PROBLEMAS....
	BEGIN CATCH   
		--
		IF ((SELECT CURSOR_STATUS('global', 'detalle_cursor')) = 1 ) BEGIN         
			CLOSE      detalle_cursor         
			DEALLOCATE detalle_cursor   
		END   
		--
		IF ( @@TRANCOUNT > 0 ) ROLLBACK TRANSACTION    
		select 'error' as resultado, @ErrMsg as el_error, @Error as id_error  ;  
		--
	END CATCH ;
END;
go


