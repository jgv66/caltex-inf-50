--
CREATE TABLE [dbo].[ktb_socio_precio](
	[empresa] [char](2) NULL,
	[lista] [char](3) NOT NULL,
	[codigo] [char](13) NOT NULL,
	[precio_ud1] [decimal](18, 5) NULL,
	[precio_ud2] [decimal](18, 5) NULL,
	[ultima_act] [date] NULL,
 CONSTRAINT [PK_ktb_socio_precio] PRIMARY KEY CLUSTERED 
(
	[lista] ASC,
	[codigo] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
CREATE TABLE [dbo].[ktb_socio_procesos](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[proceso] [varchar](100) NULL,
	[fecha] [datetime] NULL,
 CONSTRAINT [PK_ktb_socio_procesos] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
CREATE TABLE [dbo].[ktb_socio_stock](
	[empresa] [char](2) NOT NULL,
	[sucursal] [char](3) NOT NULL,
	[bodega] [char](3) NOT NULL,
	[codigo] [char](13) NOT NULL,
	[fisico1] [decimal](18, 3) NULL,
	[fisico2] [decimal](18, 3) NULL,
	[ultima_act] [date] NULL,
 CONSTRAINT [PK_ktb_socio_stock] PRIMARY KEY CLUSTERED 
(
	[empresa] ASC,
	[sucursal] ASC,
	[bodega] ASC,
	[codigo] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
--


-- exec ksp_socio_leerListaPrecio '01','01P'
IF OBJECT_ID('ksp_socio_leerListaPrecio', 'P') IS NOT NULL  
    DROP PROCEDURE ksp_socio_leerListaPrecio;  
GO  
CREATE PROCEDURE ksp_socio_leerListaPrecio (
    @empresa	char(2) = '', 
    @listapre	char(3) = '' ) With Encryption
AS
BEGIN
	--
    SET NOCOUNT ON;
	declare @noexisten int = 0,
			@condiferencia int = 0;	
    --
    declare @lista		char(3),
			@codigo		char(13),
			@precio1	decimal(18,5),
			@precio2	decimal(18,5),
			@algo		char(2);
	--	
	insert into ktb_socio_procesos (proceso,fecha) values ('analisis de lista de precios: '+@listapre+' empresa: '+@empresa, getdate() );
	--
    -- nuevos en precios
    with lista as ( select @empresa as empresa,KOLT as lista,TABPRE.KOPR as codigo,coalesce(PP01UD,0) as precio1,coalesce(PP02UD,0) as precio2
					from TABPRE with (nolock) 
					inner join MAEPR with (nolock) on MAEPR.KOPR=TABPRE.KOPR 
												  and MAEPR.BLOQUEAPR not in ('X','T','V')
												  and MAEPR.ATPR <>'OCU'
					inner join MAEPREM with (nolock) on MAEPREM.KOPR=MAEPR.KOPR and MAEPREM.EMPRESA=@empresa 
					where KOLT = @listapre ),
	noexisten as (	select li.*
					from lista as li
					left join ktb_socio_precio as pre with (nolock) on pre.empresa=li.empresa and pre.lista=li.lista and pre.codigo=li.codigo
					where pre.codigo is null )
	select @noexisten = count(*) from noexisten;
	insert into ktb_socio_procesos (proceso,fecha) values ('productos nuevos '+cast( @noexisten as varchar(20)), getdate() );
	-- con diferencias
    with lista as ( select @empresa as empresa,KOLT as lista,TABPRE.KOPR as codigo,coalesce(PP01UD,0) as precio1,coalesce(PP02UD,0) as precio2
					from TABPRE with (nolock) 
					inner join MAEPR with (nolock) on MAEPR.KOPR=TABPRE.KOPR 
												  and MAEPR.BLOQUEAPR not in ('X','T','V')
												  and MAEPR.ATPR <>'OCU'
					inner join MAEPREM with (nolock) on MAEPREM.KOPR=MAEPR.KOPR and MAEPREM.EMPRESA=@empresa 
					where KOLT = @listapre ),
	algodiferente as (	select li.*
					from lista as li
					inner join ktb_socio_precio as pre with (nolock) on pre.empresa=li.empresa and pre.lista=li.lista and pre.codigo=li.codigo
					where pre.precio_ud1 <> li.precio1 
					   or pre.precio_ud2 <> li.precio2)
	select @condiferencia = count(*) from algodiferente;
	insert into ktb_socio_procesos (proceso,fecha) values ('productos con diferencia '+cast( @condiferencia as varchar(20)), getdate() );
    
	-- El cursor esta abierto?
	IF ( (SELECT CURSOR_STATUS('global', 'detalle_cursor')) = 1 ) BEGIN
		CLOSE detalle_cursor		
		DEALLOCATE detalle_cursor
	END	
	--
	DECLARE detalle_cursor CURSOR FORWARD_ONLY STATIC READ_ONLY
	FOR 
    with lista as ( select @empresa as empresa,KOLT as lista,TABPRE.KOPR as codigo,coalesce(PP01UD,0) as precio1,coalesce(PP02UD,0) as precio2
					from TABPRE with (nolock) 
					inner join MAEPR with (nolock) on MAEPR.KOPR=TABPRE.KOPR 
												  and MAEPR.BLOQUEAPR not in ('X','T','V')
												  and MAEPR.ATPR <>'OCU'
					inner join MAEPREM with (nolock) on MAEPREM.KOPR=MAEPR.KOPR and MAEPREM.EMPRESA=@empresa 
					where KOLT = @listapre ),
	noexisten as (	select li.*
					from lista as li
					left join ktb_socio_precio as pre with (nolock) on pre.empresa=li.empresa and pre.lista=li.lista and pre.codigo=li.codigo
					where pre.codigo is null ),
	algodiferente as (	select li.*
					from lista as li
					inner join ktb_socio_precio as pre with (nolock) on pre.empresa=li.empresa and pre.lista=li.lista and pre.codigo=li.codigo
					where pre.precio_ud1 <> li.precio1 
					   or pre.precio_ud2 <> li.precio2)
    select lista,codigo,precio1, precio2, 'NE' as algo
    from noexisten
    union
    select ad.lista,ad.codigo,ad.precio1,ad.precio2, 'AD' as algo
    from algodiferente as ad ;
	--
	OPEN detalle_cursor  
	--
	FETCH NEXT FROM detalle_cursor INTO @lista,@codigo,@precio1,@precio2,@algo;

	WHILE ( @@FETCH_STATUS = 0 ) BEGIN     
		
		if ( @algo = 'NE' ) begin
			insert into ktb_socio_precio (empresa,lista,codigo,precio_ud1,precio_ud2,ultima_act)
			    values (@empresa,@listapre,@codigo,@precio1,@precio2,cast(getdate() as date));
		end
		else begin
			update ktb_socio_precio set precio_ud1=@precio1, precio_ud2=@precio2,ultima_act=cast(getdate() as date) 
			where empresa=@empresa 
			  and lista=@listapre
			  and codigo=@codigo;
		end;
	
		FETCH NEXT FROM detalle_cursor INTO @lista,@codigo,@precio1,@precio2,@algo;					  
	END;
	--
	CLOSE detalle_cursor  
	DEALLOCATE detalle_cursor  
	--	
	insert into ktb_socio_procesos (proceso,fecha) values ('fin analisis', getdate() );
	--
END;
go


