
IF ( OBJECT_ID('XMTS_AsignaFolio', 'P') IS NOT NULL ) begin
    DROP PROCEDURE XMTS_AsignaFolio;  
end;
GO  
create PROCEDURE [dbo].[XMTS_AsignaFolio] (
    @idDoc           int,
    @Modalidad       char(5),
    @ReturnValue     int             output,
    @Error           int             output, 
    @ErrMsg          nvarchar(2048)  output,
	@folioDefinitivo char(10) output )with encryption
AS
BEGIN
    --
    SET NOCOUNT ON
    --
    set @ReturnValue = 0;
    set @Error  = 0;
    set @ErrMsg = '';
    --
    Declare @modalidadDefault char(5) = CHAR(5) + ' ' + CHAR(5) + ' ' + CHAR(5),
            @folioDTE      varchar(10),
            @sucursalId    varchar(5),
            @bodegaId      varchar(5),
            @cajaId        varchar(5),
            @Empresa       varchar(2),
            @folioINT      int,
            @actualiza     bit = 1,
            @tipoDocumento as char(3),
            @idMaeedo      int = @idDoc,
            @CantPedidos   varchar(30);
    --  rescato datos desde el documento
    SELECT  @Empresa = EMPRESA
            ,@tipoDocumento = TIDO
    FROM MAEEDO with (nolock)
    WHERE IDMAEEDO = @idDoc;
    -- Obtengo datos desde la Modalidad seleccionada
    SELECT  @folioDTE = case when @tipoDocumento = 'BLV' then BLV else FCV end
            ,@sucursalId = ESUCURSAL
            ,@bodegaId = EBODEGA
            ,@cajaId = ECAJA
    FROM CONFIEST WITH (NOLOCK)
    WHERE MODALIDAD = @Modalidad
      AND EMPRESA = @Empresa;
    -- BEGIN TRY
        -- Si folioDTE = vacio en la modalidad respectiva, busco folio en Modalidad general según tipo documento
        IF ( @folioDTE = '' ) BEGIN
            --        
            SET @folioDTE = (SELECT ( case when @tipoDocumento = 'BLV' then BLV else FCV end) 
                            FROM CONFIEST WITH (NOLOCK) 
                            WHERE MODALIDAD = @modalidadDefault 
                            AND EMPRESA = @Empresa );
            --
            IF ( @folioDTE = '0000000000' ) BEGIN
                -- 
                set @actualiza = 0;
                -- ultimo mas uno
                SET @folioINT = CAST(COALESCE(( SELECT MAX(NUDO) 
                                                FROM MAEEDO WITH (NOLOCK) 
                                                WHERE EMPRESA = @Empresa 
                                                AND TIDO = @tipoDocumento 
                                                AND NUDONODEFI = 0 ), '0000000001') AS INT) + 1;
                SET @folioDTE = RIGHT('0000000000' + LTRIM(RTRIM(CAST(@folioINT AS VARCHAR(10)))), 10);
                --
            END;
            --
            UPDATE MAEEDO SET NUDO = @folioDTE, NUDONODEFI = 0, NUTRANSMI = 'totem' WHERE IDMAEEDO = @idMaeedo;
            -- existe el folio?
            IF ( ( SELECT COUNT(*) FROM MAEEDO WITH (NOLOCK) WHERE EMPRESA = @Empresa AND TIDO = @tipoDocumento AND NUDO = @folioDTE AND NUDONODEFI = 0 ) > 1 ) BEGIN
                --
                SET @ReturnValue = 0;
                set @Error       = 50100;
                set @ErrMsg      = 'FOLIO REPETIDO';
                THROW @Error, @ErrMsg, 1;
            END; 
            --
            UPDATE MAEDDO SET NUDO = @folioDTE WHERE IDMAEEDO = @idMaeedo;
			set @folioDefinitivo = @folioDTE;

            -- Resultado
            SET @ReturnValue = cast( @folioDTE as int );
            -- confiest solo se actualiza si hay numeracion fija, es decir, @actualiza = 1, el otro es el max()
            if ( @actualiza = 1 ) begin
                --
                IF ( @tipoDocumento = 'BLV' ) BEGIN
                    UPDATE CONFIEST SET BLV = REPLACE(STR(CAST(@folioDTE AS INT) + 1, 10), ' ', '0') WHERE MODALIDAD = @modalidadDefault AND EMPRESA = @Empresa;
                END
                ELSE BEGIN
                    UPDATE CONFIEST SET FCV = REPLACE(STR(CAST(@folioDTE AS INT) + 1, 10), ' ', '0') WHERE MODALIDAD = @modalidadDefault AND EMPRESA = @Empresa;
                END;
            END;
            --
        END;
        -- debe dar numeracion por la modalidad entregada
        ELSE BEGIN
            IF ( @folioDTE = '0000000000' ) BEGIN
                --
                set @actualiza = 0;
                --
                SET @folioINT = CAST(COALESCE(( SELECT MAX(NUDO) 
                                                FROM MAEEDO WITH (NOLOCK) 
                                                WHERE EMPRESA = '01'  --@Empresa 
                                                AND TIDO = 'BLV' --@tipoDocumento 
                                                AND NUDONODEFI = 0 ), '0000000001') AS INT) + 1;
                SET @folioDTE = RIGHT('0000000000' + LTRIM(RTRIM(CAST(@folioINT AS VARCHAR(10)))), 10);
                --
            END;
            --
            UPDATE MAEEDO SET NUDO = @folioDTE,NUDONODEFI = 0,NUTRANSMI = 'totem' WHERE IDMAEEDO = @idMaeedo;
            -- existe el folio?
            IF ( ( SELECT COUNT(*) FROM MAEEDO WITH (NOLOCK) WHERE EMPRESA = @Empresa AND TIDO = @tipoDocumento AND NUDONODEFI = 0 AND NUDO = @folioDTE ) > 1 ) BEGIN
                --
                SET @ReturnValue = 0;
                set @Error       = 50100;
                set @ErrMsg      = 'FOLIO REPETIDO';
                THROW @Error, @ErrMsg, 1;
            END;
            --
            UPDATE MAEDDO SET NUDO = @folioDTE WHERE IDMAEEDO = @idMaeedo;
			set @folioDefinitivo = @folioDTE;
            -- 
            SET @ReturnValue = CAST( @folioDTE as int);
            -- confiest solo se actualiza si hay numeracion fija, es decir, @actualiza = 1, el otro es el max()
            if ( @actualiza = 1 ) begin
                --
                IF ( @tipoDocumento = 'BLV' ) BEGIN
                    UPDATE CONFIEST SET BLV = REPLACE(STR(CAST(@folioDTE AS INT) + 1, 10), ' ', '0') WHERE MODALIDAD = @Modalidad AND EMPRESA = @Empresa;
                END
                ELSE BEGIN
                    UPDATE CONFIEST SET FCV = REPLACE(STR(CAST(@folioDTE AS INT) + 1, 10), ' ', '0') WHERE MODALIDAD = @Modalidad AND EMPRESA = @Empresa;
                END;
				--
            END;
        END;
        --
END;
